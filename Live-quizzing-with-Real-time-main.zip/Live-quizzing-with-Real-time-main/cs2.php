<html>
<head>
<style>


#con{ border-radius: 10px,10px;
	  width: 100%;
	height:1000px;

       margin-left:auto;
	   margin-right:auto;
	   margin-top:15px
	   background-color:green;
}
#header{ border-radius: 10px;
	
	height:65px;
	width:full;
	 
	background: linear-gradient(to left, yellow, tomato);
	}
	

#menu{border-radius: 10px ,10px;
	margin-top:10;
	height:60px;
	width:60px;
	background-color:grey;
}


#mainbody{ border-radius: 10px;
	margin-top:0;
	 width:full;
	 height:880px;;
	 background: cornsilk;
	 
	 
}
#rotate{
     width:600px;
	 height:170px;
	 margin-left:330px;
	   
	 	 background-color:white;
		body-aligin:center;
}
#write{
  border-radius: 10px;
   width:600px;
   height:70px;
   margin-left:330px;
   margin-top:10px;
   background-color:white;


}
#dtext1{
  border-radius: 10px;
   width:600px;
   height:400px;
   margin-left:330px;
   margin-top:10px;
   background-color:black;


}
#dtext2{
  border-radius: 10px;
   width:300px;
   height:80px;
   margin-left:0px;
   margin-top:10px;
   background-color:white;
   float:left;
  


}
#dtext3{
  border-radius: 10px;
   width:300px;
   height:80px;
   margin-left:0px;
   margin-top:10px;
   background-color:white;
   float:right;
  


}

#sidebar{
border-radius: 10px;
   width:200px;
   height:70px;
   margin-left:50px;
   margin-top:6px;
   margin-bottom:5px;
   position:relative;
   background-color:#E67451 ;
   float:left;



}
#side{
border-radius: 10px;
   width:200px;
   height:70px;
   margin-left:50px;
   margin-right:50px;
   margin-top:5px;
   
   background-color:#E67451;
   float:right;



}

#footer{
	 border-radius: 10px;
	 margin-top:10px;
	height:60px;
	margin-bottom:10px;
	background: linear-gradient(to left, orange	, tomato);
	
} /*shadow */
#dtext {
border-radius: 10px;
color: #FFFFFF;
background: #333333;
text-shadow: #FFF 0px 0px 0px, orange 0px 0px 10px, #FF8C00 0px 0px 15px, #FF8C00 0px 0px 20px, 	#FF8C00 0px 0px 30px, 	#FF8C00 0px 0px 40px, 	#FF8C00 0px 0px 50px, #FF8C00 0px 0px 75px;
color: #FFFFFF;
background: black;
}

</style>
</head>
<body>
<div id="con">
<div id="header"> 

</div>
<div id="mainbody">


</div>
</div>
</body>
</html>
