<?php 
 
$name=$_POST["name"];
$name++;
echo "hellllllll".$name;
